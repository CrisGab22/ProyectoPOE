En esta carpeta va toda la logica que funciona entre intermediario entre el modelo (base de datos) y vista (UI), aca pueden ir:
- Servicios
- Validaciones
- Helpers