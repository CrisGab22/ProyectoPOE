En esta carpeta va la interfaz de usuario, como por ejemplo:
- formularios
- ventanas
- menus
- reportes

De momento pueden crear un Tab